﻿console.log("background.js");
chrome.runtime.onMessageExternal.addListener((request, sender, sendResponse) => {
  console.log(request);
  console.log(sender);
});