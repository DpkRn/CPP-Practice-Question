﻿function googleTranslateElementInit() {
  console.log("googleTranslateElementInit");
  let lang = document.documentElement.lang;
  console.log("[" + lang + "]");
  if (lang == "") lang = "en";
  new google.translate.TranslateElement(
    {
      pageLanguage: lang,
      includedLanguages: "ja,en,fr"
    },
    "google_translate_element"
  );
};

const div = document.createElement("div");
div.id = "google_translate_element";
document.body.insertBefore(div, document.body.children[0]);

const script = document.createElement("script");
script.type = "text/javascript";
script.src = "//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit";
document.body.appendChild(script);