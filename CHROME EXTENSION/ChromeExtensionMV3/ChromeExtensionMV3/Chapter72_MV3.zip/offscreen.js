﻿const audio = document.getElementById("audio");

chrome.runtime.onMessage.addListener((message) => {
  switch (message) {
    case "play":
      audio.play();
      break;
    case "pause":
      audio.pause();
      break;
  }
});