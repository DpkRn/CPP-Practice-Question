﻿document.getElementById("play").onclick = () => {
  chrome.offscreen.createDocument({
    url: chrome.runtime.getURL("offscreen.html"),
    reasons: ["AUDIO_PLAYBACK"],
    justification: "justification is required.",
  }, () => {
    chrome.runtime.sendMessage("play");
  });
}

document.getElementById("pause").onclick = () => {
  chrome.runtime.sendMessage("pause");
}