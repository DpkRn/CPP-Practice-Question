﻿chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason != "install") return;

  chrome.windows.create({
    width : 400,
    height : 100,
    type : "popup",
    url : "install.html"
  });

  chrome.runtime.setUninstallURL("https://nory-soft.web.app/uninstalled.html");
});