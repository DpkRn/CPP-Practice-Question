﻿window.onload = () => {
  chrome.windows.getCurrent((cw) => {
    let w, h;
    if (cw.state == 'maximized'){
      w = 'Max';
      h = 'Max';
    }
    else{
      w = cw.width - 14;
      h = cw.height - 7;
    }
    document.getElementById('id_width').value = w;
    document.getElementById('id_height').value = h;
  });
}
document.getElementById('id_move').onclick = () => {
  chrome.windows.getCurrent((cw) => {
    chrome.windows.update(cw.id, {
      top : 0,
      left : -7
    });
  });
}
document.getElementById('id_change').onclick = () => {
  let w = document.getElementById('id_width').value;
  let h = document.getElementById('id_height').value;
  setWindowsSize(w, h);
}
function setWindowsSize(w, h) {
  chrome.windows.getCurrent((cw) => {
    chrome.windows.update(cw.id, {
      width : parseInt(w) + 14,
      height : parseInt(h) + 7
    });	
  });
}