﻿const elmUserAgent = document.getElementById("userAgent");
const elmOn = document.getElementById("on");
const elmOff = document.getElementById("off");

//elmUserAgent.value = "Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1";
elmUserAgent.value = "Mozilla/5.0 (Linux; Android 11; Pixel 5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.91 Mobile Safari/537.36";

//chrome.declarativeNetRequest.getDynamicRules(rules => console.log(rules));

elmOn.onclick = () => {
  const rules = {
    removeRuleIds: [1],
    addRules: [
      {
        id: 1,
        priority: 1,
        action: {
          type: "modifyHeaders",
          requestHeaders: [
            {
              header: "user-agent",
              operation: "set",
              value: elmUserAgent.value,
            },
          ],
        },
        condition: {
          urlFilter: "*",
          resourceTypes: [
            "main_frame"
          ],
        },
      },
    ],
  }

  chrome.declarativeNetRequest.updateDynamicRules(rules);
}

elmOff.onclick = () => {
  const rules = {
    removeRuleIds: [1]
  }

  chrome.declarativeNetRequest.updateDynamicRules(rules);
}