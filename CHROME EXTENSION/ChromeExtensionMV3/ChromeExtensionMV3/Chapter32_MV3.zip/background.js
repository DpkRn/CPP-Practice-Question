﻿let opt = {
  progress: 0
}

chrome.alarms.onAlarm.addListener(() => {
  opt.progress += 10;
  chrome.notifications.update("hoge", opt);

  if (opt.progress == 100){
    opt.progress = 0;
  }
  else{
    let dt = new Date();
    dt.setSeconds(dt.getSeconds() + 2);
    chrome.alarms.create({when: dt.getTime()});
  }
});