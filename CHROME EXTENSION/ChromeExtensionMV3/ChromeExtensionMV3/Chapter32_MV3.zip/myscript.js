﻿document.getElementById("id_basic").onclick = () => {
  let opt = {
    type: "basic",
    title: "Primary Title",
    message: "Primary message to display",
    iconUrl: "Chapter_32_32.png"
  }
  chrome.notifications.create(opt);
}

document.getElementById("id_image").onclick = () => {
  let opt = {
    type: "image",
    title: "Primary Title",
    message: "Primary message to display",
    iconUrl: "Chapter_32_32.png",
    imageUrl: "neko.png"
  }
  chrome.notifications.create(opt);
}

document.getElementById("id_list").onclick = () => {
  let opt = {
    type: "list",
    title: "Primary Title",
    message: "Primary message to display",
    iconUrl: "Chapter_32_32.png",
    items: [{ title: "Item1", message: "This is item 1."},
            { title: "Item2", message: "This is item 2."},
            { title: "Item3", message: "This is item 3."}]
  }
  chrome.notifications.create(opt);
}

document.getElementById("id_progress").onclick = () => {
  let opt = {
    type: "progress",
    title: "Primary Title",
    message: "Primary message to display",
    iconUrl: "Chapter_32_32.png",
    progress: 0
  }
  chrome.notifications.create("hoge", opt);

  let dt = new Date();
  dt.setSeconds(dt.getSeconds() + 5);
  chrome.alarms.create({when: dt.getTime()});
}