﻿window.onload = () => {
  let errorcode = chrome.i18n.getMessage("errorcode");
  let subcode = chrome.i18n.getMessage("subcode");
  let disp = chrome.i18n.getMessage("disp");

  document.getElementById("id_label1").innerText = errorcode;
  document.getElementById("id_label2").innerText = subcode;
  document.getElementById("id_disp").value = disp;
}

document.getElementById("id_disp").onclick = () => {
  let errorcode = document.getElementById("id_errorcode").value;
  let subcode = document.getElementById("id_subcode").value;

  let errormessage1 = chrome.i18n.getMessage("errormessage1",errorcode);
  document.getElementById("id_errormessage1").value = errormessage1;

  let errormessage2 = chrome.i18n.getMessage("errormessage2",[errorcode, subcode]);
  document.getElementById("id_errormessage2").value = errormessage2;
}