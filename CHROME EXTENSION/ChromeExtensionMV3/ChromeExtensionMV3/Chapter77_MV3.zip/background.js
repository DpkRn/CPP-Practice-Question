﻿chrome.offscreen.createDocument({
  url: "offscreen.html",
  reasons: [chrome.offscreen.Reason.IFRAME_SCRIPTING],
  justification: "Using eval in sandbox."
});

let count = 1;

chrome.action.onClicked.addListener(async () => {
  // const data = eval("count ** 2");
  const res = await chrome.runtime.sendMessage(count++);
  console.log("result of eval = " + res);
  chrome.action.setBadgeText({ text: String(res) });
});
