﻿window.addEventListener("message", (event) => {
  const data = eval("event.data ** 2");
  event.source.postMessage(data, event.origin);
});