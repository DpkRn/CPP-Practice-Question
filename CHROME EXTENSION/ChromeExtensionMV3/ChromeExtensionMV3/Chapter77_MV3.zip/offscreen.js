﻿const iframe = document.getElementById("iframe");

chrome.runtime.onMessage.addListener((count, sender, sendResponse) => {
  iframe.contentWindow.postMessage(count, "*");

  window.addEventListener("message", (event) => {
    sendResponse(event.data);
  }, false);

  return true;
});