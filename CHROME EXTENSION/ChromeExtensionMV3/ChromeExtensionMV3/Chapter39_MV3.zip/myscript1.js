window.onload = () => {
  chrome.tabs.create({url: "index.html"});
}