﻿const elmOutput = document.getElementById("output");
const elmList = document.getElementById("list");
const elmId = document.getElementById("id");
const elmEnable = document.getElementById("enable");
const elmDisable = document.getElementById("disable");

elmList.onclick = () => {
  chrome.management.getAll((infoes) => {
    let text = "";
    for (let info of infoes) {
      if (info.isApp) continue;
      text += info.enabled + "," + info.id + "," + info.name + "\n";
      elmOutput.value = text;
    }
  });
};

elmEnable.onclick = () => {
  const id = elmId.value;
  chrome.management.setEnabled(id, true);
};

elmDisable.onclick = () => {
  const id = elmId.value;
  chrome.management.setEnabled(id, false);
};
