﻿document.getElementById("id_change").onclick = () => {
  chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
    chrome.storage.sync.get({
      bgColor: "red"
    }, (item) => {
      chrome.scripting.executeScript({
        target: {tabId: tabs[0].id},
        function: setBackGroundColor,
        args: [item.bgColor],
      });
    });
  });
}

function setBackGroundColor(color){
  document.body.style.backgroundColor = color;
}