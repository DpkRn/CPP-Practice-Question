﻿const elmText = document.getElementById("text");

chrome.identity.getAuthToken({ interactive: true }, function (token) {
  console.log(token);
  if (token == null) {
    elmText.value = "Login fail.";
    return;
  }

  elmText.value = "Login success.";
  let init = {
    method: 'GET',
    async: true,
    headers: {
      Authorization: 'Bearer ' + token,
      'Content-Type': 'application/json'
    },
    'contentType': 'json'
  };
  fetch(
    'https://www.googleapis.com/oauth2/v1/userinfo?', init)
    .then((response) => response.json())
    .then(function (data) {
      console.log(data)
      elmText.value += "\n\nemail:" + data.email;
    });
});