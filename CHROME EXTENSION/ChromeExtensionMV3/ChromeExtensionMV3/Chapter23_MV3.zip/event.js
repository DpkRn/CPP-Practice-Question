﻿let alarm = false;

chrome.action.onClicked.addListener(() => {
  if (!alarm){
    setAlarm();
    alarm = true;
  }
  else{
    clearAlarm();
    alarm = false;
  }
});

const text = ["ok", "ng"];
const color = ["green", "red"];
let index = 0;

chrome.alarms.onAlarm.addListener(() => {
  chrome.action.setBadgeText({text: text[index]}, () => {});
  chrome.action.setBadgeBackgroundColor({color: color[index]}, () => {});
  index = (index == 0 ? 1 : 0);
  setAlarm();
});

const alarm_id = "alarm_id";

function setAlarm(){
  let dt = new Date();
  dt.setSeconds(dt.getSeconds() + 1);
  chrome.alarms.create(alarm_id, {when: dt.getTime()});
}

function clearAlarm(){
  chrome.alarms.clear(alarm_id);
}