﻿window.onload = function () {
  const createDate = {
    url: "player.html",
    type: "popup"
  };
  chrome.windows.create(createDate, () => { });
}