const style = document.createElement("style");
style.innerHTML = ".hide {display: none;}"
  + ".display {"
  + "  position: absolute;"
  + "  border: 2px solid red;"
  + "  background-color: white;"
  + "}";
document.head.insertBefore(style, null);

const tagInfo = document.createElement("span");

const allElm = document.body.getElementsByTagName("*");

for (let i = 0; i < allElm.length; i++) {
  let elm = allElm[i];
  elm.addEventListener("mouseenter", (e) => {
    let outerHTML = elm.outerHTML;
    outerHTML = outerHTML.substring(0, 100);
    outerHTML = outerHTML.replace(/\</g, "&lt;");
    outerHTML = outerHTML.replace(/\>/g, "&gt;");
    tagInfo.innerHTML = outerHTML;
    tagInfo.className = "display";
    tagInfo.style.left = e.pageX + "px";
    tagInfo.style.top = e.pageY + "px";
  });
}

tagInfo.className = "hide"
document.body.insertBefore(tagInfo, null);