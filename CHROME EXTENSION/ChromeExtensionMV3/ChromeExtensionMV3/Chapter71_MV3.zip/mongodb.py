import sys
import json
import struct
from pymongo import MongoClient

serverConfig = "mongodb+srv://<user>:<pass>@<clusterX.XXXXXXX>.mongodb.net/?retryWrites=true&w=majority"

def getMessage():
    rawLength = sys.stdin.buffer.read(4)
    messageLength = struct.unpack("@I", rawLength)[0]
    message = sys.stdin.buffer.read(messageLength).decode("utf-8")
    return json.loads(message)


def encodeMessage(messageContent):
    encodedContent = json.dumps(messageContent).encode("utf-8")
    encodedLength = struct.pack("@I", len(encodedContent))
    return {"length": encodedLength, "content": encodedContent}


def sendMessage(encodedMessage):
    sys.stdout.buffer.write(encodedMessage["length"])
    sys.stdout.buffer.write(encodedMessage["content"])
    sys.stdout.buffer.flush()


def main():
    client = MongoClient(serverConfig)
    db = client.testdb

    while True:
        command = getMessage()
        if (command["kind"]== "find"):
            rows = db.testdb.find()
            result = ""
            for row in rows:
                result += str(row) + "\n"
            sendMessage(encodeMessage(result))
        else:
            db.testdb.insert_one(command["insert"])

main()