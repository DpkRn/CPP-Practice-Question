const elmKey = document.getElementById("key");
const elmValue = document.getElementById("value");
const elmInsert = document.getElementById("insert");
const elmResult = document.getElementById("result");
const elmFind = document.getElementById("find");

const port = chrome.runtime.connectNative("mongodb");

elmInsert.onclick = () => {
  let row = {};
  row[elmKey.value] = elmValue.value;
  port.postMessage({ kind: "insert", insert: row });
}

elmFind.onclick = () => {
  port.postMessage({ kind: "find" });
}

port.onMessage.addListener((message) => {
  elmResult.value = message;
});