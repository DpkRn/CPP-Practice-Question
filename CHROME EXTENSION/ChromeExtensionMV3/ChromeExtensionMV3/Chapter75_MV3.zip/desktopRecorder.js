﻿const init = async () => {
  const w = await chrome.windows.getCurrent({});
  await chrome.windows.update(w.id, { focused: true });
}

init();

let recorder = null;

document.getElementById("captuer").onclick = async () => {
  const sources = ["screen", "window", "tab", "audio"];

  const tab = await chrome.tabs.getCurrent();

  chrome.desktopCapture.chooseDesktopMedia(sources, tab, async (streamId) => {
    const stream = await navigator.mediaDevices.getUserMedia({
      audio: {
        mandatory: {
          chromeMediaSource: "desktop",
          chromeMediaSourceId: streamId
        }
      },
      video: {
        mandatory: {
          chromeMediaSource: "desktop",
          chromeMediaSourceId: streamId
        }
      }
    });
    console.log(stream);
    recorder = new MediaRecorder(stream);
    const chunks = [];

    recorder.ondataavailable = (e) => {
      chunks.push(e.data);
    };

    recorder.onstop = (e) => {
      running = false;
      const blob = new Blob(chunks, { type: "video/mp4;codecs=avc1" });
      url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.download = "download.mp4";
      a.href = url;
      a.click();
    }

    recorder.start();
  });
}

document.getElementById("stop").onclick = () => {
  recorder.stop();
}