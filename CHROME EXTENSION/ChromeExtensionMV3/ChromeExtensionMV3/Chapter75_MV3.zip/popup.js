﻿const createDate = {
  url: "desktopRecorder.html",
  type: "popup",
  width: 800,
  height: 600
};
chrome.windows.create(createDate);

window.close();