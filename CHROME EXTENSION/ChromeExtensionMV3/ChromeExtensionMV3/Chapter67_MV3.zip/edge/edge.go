package main

import (
	"bufio"
	"bytes"
	"encoding/binary"
	"io"
	"os"
	"os/exec"
	"unsafe"
)

var program = "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe"

var bufferSize = 8192
var nativeEndian binary.ByteOrder

func main() {
	var one int16 = 1
	b := (*byte)(unsafe.Pointer(&one))
	if *b == 0 {
		nativeEndian = binary.BigEndian
	} else {
		nativeEndian = binary.LittleEndian
	}
	read()
}

func read() {
	v := bufio.NewReader(os.Stdin)
	s := bufio.NewReaderSize(v, bufferSize)

	lengthBytes := make([]byte, 4)
	lengthNum := int(0)

	for b, err := s.Read(lengthBytes); b > 0 && err == nil; b, err = s.Read(lengthBytes) {
		lengthNum = readMessageLength(lengthBytes)

		content := make([]byte, lengthNum)
		_, err := s.Read(content)
		if err != nil && err != io.EOF {
			panic(err)
		}

		parseMessage(content)
	}
}

func readMessageLength(msg []byte) int {
	var length uint32
	buf := bytes.NewBuffer(msg)
	err := binary.Read(buf, nativeEndian, &length)
	if err != nil {
		panic(err)
	}
	return int(length)
}

func parseMessage(msg []byte) {
	url := string(msg)
	urlLengh := len(url)
	url = url[1 : urlLengh-1]

	exec.Command(program, url).Run()
}
