chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
  const port = chrome.runtime.connectNative("goedge");
  port.postMessage(tabs[0].url);
});