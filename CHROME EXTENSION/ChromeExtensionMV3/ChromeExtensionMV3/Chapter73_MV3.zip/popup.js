const createDate = {
  url: "voiceRecorder.html",
  type: "popup",
  width: 400,
  height: 200
};

chrome.windows.create(createDate);