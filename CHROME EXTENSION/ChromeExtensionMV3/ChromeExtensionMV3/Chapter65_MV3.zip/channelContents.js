﻿const apikey = "<Your API Key>";

const elmChannelName = document.getElementById("channelName");
const elmSearch = document.getElementById("search");
const elmResult = document.getElementById("result");
const elmChannelId = document.getElementById("channelId");
const elmGet = document.getElementById("get");
const elmChannelContents = document.getElementById("channelContents");

elmSearch.onclick = async () => {
  elmResult.value = await getChannelIds(elmChannelName.value);
}

elmGet.onclick = async () => {
  let nextPageToken = null;

  while (true) {
    nextPageToken = await getChannelContents(elmChannelId.value, nextPageToken);
    console.log("nextPageToken=" + nextPageToken);
    // I only get the first 5 on purpose to avoid hitting the quota limit.
    break;
    if (!nextPageToken) break;
  }
}

const fetchYoutebeDataAPI = async (url) => {
  console.log("fetchYoutebeDataAPI()");

  url += "&key=" + apikey;

  const response = await fetch(url);

  return await response.json();
}

const getChannelIds = async (cnannelName) => {
  console.log("getChannelIds()");

  let url = "https://www.googleapis.com/youtube/v3/search";
  url += "?part=snippet";
  url += "&type=channel";
  //  url += "&maxResults=50";
  url += "&q=" + cnannelName;

  const response = await fetchYoutebeDataAPI(url);

  let result = "";

  for (const { snippet } of response.items) {
    result += snippet.channelId + "," + snippet.title + "\n";
  }

  return result;
}

const getChannelContents = async (cnannelId, nextPageToken = null) => {
  console.log("getChannelContents()");

  let url = "https://www.googleapis.com/youtube/v3/search";
  url += "?part=snippet";
  url += "&type=video";
  //  url += "&maxResults=50";
  url += "&order=date";
  url += "&channelId=" + cnannelId;

  if (nextPageToken != null) {
    url += "&pageToken=" + nextPageToken;
  }

  const response = await fetchYoutebeDataAPI(url);

  for (const { id, snippet } of response.items) {
    const url = "https://youtu.be/" + id.videoId;
    const title = snippet.title;
    const a = "<a href='" + url + "'>" + title + "</a><br>";
    elmChannelContents.insertAdjacentHTML("afterbegin", a);
  }

  return response.nextPageToken;
}