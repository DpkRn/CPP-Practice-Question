﻿chrome.tabs.create({ url: "search.html" });

window.close();