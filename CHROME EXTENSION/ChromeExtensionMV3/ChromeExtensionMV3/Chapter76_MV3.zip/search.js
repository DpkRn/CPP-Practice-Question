﻿const country = document.getElementById("country");
const text = document.getElementById("text");
const search = document.getElementById("search");

const countryValue = localStorage["countryValue"];

if (countryValue != null) {
  country.value = countryValue;
}

country.onchange = () => {
  localStorage["countryValue"] = country.value;
}

const form = document.createElement("form");
form.action = "https://www.google.co.jp/search";
form.method = "GET";
document.body.append(form);

form.onformdata = (e) => {
  const fd = e.formData;
  fd.set("q", text.value);
  if (country.value != "non") {
    fd.set("gl", country.value);
  }
  fd.set("sa", "Search");
}

search.onclick = () => {
  form.submit();
}