﻿window.onload = function(){
  chrome.tabs.create({url: "imagePaste.html"}, tab => {});
}