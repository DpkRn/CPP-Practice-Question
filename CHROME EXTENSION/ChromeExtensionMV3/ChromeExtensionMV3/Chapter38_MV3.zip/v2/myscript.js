﻿document.getElementById("id_check").onclick = () => {
  let phoneNumber = document.getElementById("id_phoneNumber").value;
  let country = document.getElementById("id_country").value;

  let status = libphonenumber.isValidNumber(phoneNumber, country);

  document.getElementById("id_status").value = status;
}