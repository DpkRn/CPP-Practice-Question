﻿const createDate = {
  url: "desktopCaptuer.html",
  type: "popup",
  width: 800,
  height: 600
};
chrome.windows.create(createDate);