﻿window.onload = () => {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    chrome.scripting.executeScript({
      target: { tabId: tabs[0].id },
      func: getFilename
    });
  });
}

function getFilename() {
  console.log("getFilename");
  let fileName = document.getElementById("id_filename").innerText;
  console.log("fineName=" + fileName);
  navigator.clipboard.writeText(fileName);
  console.log("Wrote it on the click board");
}