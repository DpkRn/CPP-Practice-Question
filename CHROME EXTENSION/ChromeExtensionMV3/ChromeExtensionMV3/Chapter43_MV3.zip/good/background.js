chrome.action.onClicked.addListener((tab) => {
  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: getFilename
  });
});

function getFilename() {
  console.log("getFilename");
  let fileName = document.getElementById("id_filename").innerText;
  console.log("fineName=" + fileName);
  navigator.clipboard.writeText(fileName);
  console.log("Wrote it on the click board");
}