const iframe = document.getElementById("iframe");

document.getElementById("signin").onclick = () => {
  chrome.identity.getAuthToken({ interactive: true }, token => {
    console.log(token);
    if (token != null) {
      iframe.contentWindow.postMessage(token, "*");
    }
  });
}