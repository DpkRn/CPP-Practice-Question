﻿const elOpen = document.getElementById("id_open");
const elSave = document.getElementById("id_save");
const elFile = document.getElementById("id_file");
const elText = document.getElementById("id_text");

let windowInitHeight;
let textInitHeight;

// Called when this html file is loaded.
window.onload = function(){
  // Bring the window to the top.
  chrome.windows.getCurrent({}, w => {
    chrome.windows.update(w.id, {focused: true}, () => {});
  });
  windowInitHeight = window.innerHeight;
  textInitHeight = elText.offsetHeight;
}

// Synchronize the height of window and textarea.
window.addEventListener("DOMContentLoaded", () => {
  window.addEventListener("resize", () => {
    const height = window.innerHeight - windowInitHeight + textInitHeight;
    elText.style.height = height + "px";
  });
});

elOpen.onchange = () => {
  if (elOpen.files[0] == null) return;
  const reader = new FileReader;
  reader.onload = () => {
    elText.value = reader.result;
  }
  reader.readAsText(elOpen.files[0]);
  elFile.value = elOpen.files[0].name;
}

elSave.onclick = () => {
  const a = document.createElement("a");
  a.href = window.URL.createObjectURL(new Blob([elText.value]));
  a.download = elFile.value;
  a.click();
}