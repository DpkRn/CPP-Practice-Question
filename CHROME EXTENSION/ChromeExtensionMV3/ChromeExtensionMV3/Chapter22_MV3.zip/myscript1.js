﻿window.onload = function(){
  const createDate = {
    url: "notePad.html",
    type: "popup",
    width: 400,
    height:400
  };
  chrome.windows.create(createDate, () => {});
}