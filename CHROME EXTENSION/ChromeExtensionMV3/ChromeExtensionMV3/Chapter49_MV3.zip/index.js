const phoneUtil = require("google-libphonenumber").PhoneNumberUtil.getInstance();

document.getElementById("id_check").onclick = () => {
  const phoneNumber = document.getElementById("id_phoneNumber").value;
  const country = document.getElementById("id_country").value;
  const phoneNumberObj = phoneUtil.parseAndKeepRawInput(phoneNumber, country);
  const status = phoneUtil.isValidNumberForRegion(phoneNumberObj, country);
  document.getElementById("id_status").value = status;
}