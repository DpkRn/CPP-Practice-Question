﻿const elmHost = document.getElementById("host");
const elmPort = document.getElementById("port");
const elmBypassList = document.getElementById("bypassList");
const elmSet = document.getElementById("set");
const elmGet = document.getElementById("get");
const elmDefault = document.getElementById("default");
const elmText = document.getElementById("text");

elmSet.onclick = () => {
  const config = {
    mode: "fixed_servers",
    rules: {
      proxyForHttps: {
        host: elmHost.value,
        port: parseInt(elmPort.value, 10)
      },
      bypassList: [elmBypassList.value]
    }
  };

  chrome.proxy.settings.set(
    { value: config, scope: "regular" }
  );
}

elmGet.onclick = () => {
  chrome.proxy.settings.get(
    { "incognito": false },
    (config) => {
      elmText.value = JSON.stringify(config);
    }
  );
}

elmDefault.onclick = () => {
  const config = {
    mode: "system"
  };

  chrome.proxy.settings.set(
    { value: config, scope: "regular" }
  );
}