﻿// Called when popup.html is loaded.
window.onload = () => {
  console.log('window.onload:Start');
  // Load localStorage with Key = 'Memo'.
  // If it does not exist, the value is null.
  let memo = localStorage['Memo'];
  console.log('load memo=[', memo, ']');
  if (memo == null){
    memo = '';
  }
  document.getElementById('id_memo').value = memo;
  console.log('window.onload:End');
}
// Click save button
document.getElementById('id_save').onclick = () => {
  console.log('save button onclick:Start');
  console.log('save memo=[', document.getElementById('id_memo').value, ']');
  // Load localStorage with Key = 'Memo'.
  localStorage['Memo'] = document.getElementById('id_memo').value;
  console.log('save button onclick:End');
}