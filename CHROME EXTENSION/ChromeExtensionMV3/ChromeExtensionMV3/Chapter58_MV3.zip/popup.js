﻿const elmPermissions = document.getElementById("permissions");
const elmOrigins = document.getElementById("origins");
const elmRequest = document.getElementById("request");
const elmGetAll = document.getElementById("getAll");

elmRequest.onclick = () => {
  chrome.permissions.request({
    permissions: [elmPermissions.value],
    origins: [elmOrigins.value]
  }, (granted) => {
    console.log(granted);
  });
}

elmGetAll.onclick = () => {
  chrome.permissions.getAll((permissions) => {
    console.log(permissions);
  });
}