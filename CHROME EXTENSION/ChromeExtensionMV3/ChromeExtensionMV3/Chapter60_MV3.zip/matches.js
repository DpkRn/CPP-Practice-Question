﻿const onMutation = (mutations) => {
  mo.disconnect(); // Required if you modify the DOM during this process.

  for (const mutation of mutations) {
    console.log("addedNodes.length=", mutation.addedNodes.length);
    for (const node of mutation.addedNodes) {
      console.log("addedNode.nodeName=", node.nodeName);
      console.log("addedNode.textContent=", node.textContent);
    }

    console.log("removedNodes.length=", mutation.removedNodes.length);
    for (const node of mutation.removedNodes) {
      console.log("removedNode.nodeName=", node.nodeName);
      console.log("removedNode.textContent=", node.textContent);
    }
  }

  observe(); // Required if you modify the DOM during this process.
}

const observe = () => {
  mo.observe(document, {
    subtree: true,
    childList: true,
  });
}

const mo = new MutationObserver(onMutation);

observe();