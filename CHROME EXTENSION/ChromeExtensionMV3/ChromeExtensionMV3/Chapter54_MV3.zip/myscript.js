﻿const elmMethon = document.getElementById("method");
const elmFileName = document.getElementById("fileName");
const elmContent = document.getElementById("content");
const elmExec = document.getElementById("exec");

elmExec.onclick = () => {
  const method = elmMethon.value;
  const fileName = encodeURI(elmFileName.value);
  const content = encodeURI(elmContent.value);

  let url = "xxxxxxxxxx";

  url += "?method=" + method + "&fileName=" + fileName + "&content=" + content;
  console.log(url);

  fetch(url, {
    method: "GET",
    mode: "cors"
  })
    .then(response => {
      if (response.ok) {
        return response.text();
      }
      throw new Error("Response was not ok.");
    })
    .then(data => {
      elmContent.value = data;
    })
    .catch(error => {
      elmContent.value = error;
    })
}