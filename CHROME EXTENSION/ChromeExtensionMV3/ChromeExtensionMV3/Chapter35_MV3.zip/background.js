chrome.omnibox.onInputChanged.addListener((text,suggest) => {
  let w = ["water", "wick", "wikipedia"];
  let s = [];
  for (let i = 0; i < w.length; i++){
    if (w[i].indexOf(text) == 0){
      s.push({content: w[i], description: w[i]});
    }
  }
  suggest(s);
});

chrome.omnibox.onInputEntered.addListener((text) => {
  if (text != "wikipedia") return;
  chrome.tabs.create({
    url: "https://www.wikipedia.org/"
  });
});