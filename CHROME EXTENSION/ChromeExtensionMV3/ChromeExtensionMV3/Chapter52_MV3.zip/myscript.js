﻿const elmName = document.getElementById("name");
const elmSetTime = document.getElementById("setTime");
elmSetTime.onclick = () => {
  let url = "xxxxxxxxxx";
  const name = encodeURI(elmName.value);
  url += "?name=" + name;
  console.log(url);
  fetch(url, {
    method: "GET",
    mode: "cors"
  })
}