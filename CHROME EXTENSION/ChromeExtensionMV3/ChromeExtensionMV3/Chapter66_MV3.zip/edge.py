import sys
import json
import struct
import subprocess


def getMessage():
    rawLength = sys.stdin.buffer.read(4)
    messageLength = struct.unpack("@I", rawLength)[0]
    message = sys.stdin.buffer.read(messageLength).decode("utf-8")
    return json.loads(message)


program = <Your msedge.exe Path>
url = getMessage()
run_args = [program, url]

res = subprocess.run(run_args, stdout=subprocess.PIPE)
