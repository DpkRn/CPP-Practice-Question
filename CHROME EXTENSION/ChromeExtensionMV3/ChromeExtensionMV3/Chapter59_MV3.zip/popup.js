﻿const elmCursorToWait = document.getElementById("cursorToWait");
const elmRestoreCursor = document.getElementById("restoreCursor");
const elmCursorToWaitCss = document.getElementById("cursorToWaitCss");
const elmRestoreCursorCss = document.getElementById("restoreCursorCss");

const executeScript = async (f) => {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  await chrome.scripting.executeScript({
    target: { tabId: tabs[0].id },
    func: f
  });
}

let cursor = null;

const cursorToWait = () => {
  cursor = document.body.style.cursor;
  document.body.style.cursor = "wait";
};
elmCursorToWait.onclick = () => {
  executeScript(cursorToWait);
}

const restoreCursor = () => {
  if (cursor == null) return;
  document.body.style.cursor = cursor;
};
elmRestoreCursor.onclick = () => {
  executeScript(restoreCursor);
}

const cursorToWaitCss = () => {
  const style = document.createElement("style");
  style.id = "corsor_wait";
  style.innerHTML = "* {cursor: wait;}"
  document.head.insertBefore(style, null);
};
elmCursorToWaitCss.onclick = () => {
  executeScript(cursorToWaitCss);
}

const restoreCursorCss = () => {
  document.getElementById("corsor_wait").remove();
};
elmRestoreCursorCss.onclick = () => {
  executeScript(restoreCursorCss);
}