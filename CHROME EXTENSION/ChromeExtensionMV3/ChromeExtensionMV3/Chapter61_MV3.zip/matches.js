const img = document.createElement("img");

const path = chrome.runtime.getURL("web_accessible_resources.png");

console.log("path=", path);

img.src = path;

document.body.insertBefore(img, document.body.firstElementChild);