﻿const elmRecipient = document.getElementById("recipient");
const elmSubject = document.getElementById("subject");
const elmBody = document.getElementById("body");
const elmMail = document.getElementById("mail");
elmMail.onclick = () => {
  let url = "https://script.google.com/macros/s/xxxxxxxxxx/exec";
  const recipient = elmRecipient.value;
  const subject = encodeURI(elmSubject.value);
  const body = encodeURI(elmBody.value);
  url += "?recipient=" + recipient + "&subject=" + subject + "&body=" + body;
  console.log(url);
  fetch(url, {
    method: "GET",
    mode: "cors"
  })
}