﻿const elOpen = document.getElementById("id_open");
const elSave = document.getElementById("id_save");
const elFile = document.getElementById("id_file");
const elText = document.getElementById("id_text");

let windowInitHeight;
let textInitHeight;

// Called when this html file is loaded.
window.onload = function () {
  // Bring the window to the top.
  chrome.windows.getCurrent({}, w => {
    chrome.windows.update(w.id, { focused: true }, () => { });
  });
  windowInitHeight = window.innerHeight;
  textInitHeight = elText.offsetHeight;
}

// Synchronize the height of window and textarea.
window.addEventListener("DOMContentLoaded", () => {
  window.addEventListener("resize", () => {
    const height = window.innerHeight - windowInitHeight + textInitHeight;
    elText.style.height = height + "px";
  });
});

const fileTypes = [
  {
    description: "Text file",
    accept: {
      "text/plain": [".txt"]
    }
  },
]

elOpen.onclick = async () => {
  try {
    const fhArray = await window.showOpenFilePicker({ types: fileTypes });
    const fh = fhArray[0];
    elFile.value = fh.name;
    const fd = await fh.getFile();
    elText.value = await fd.text();
  }
  catch (e) { }
}

elSave.onclick = async () => {
  try {
    const fh = await window.showSaveFilePicker({ types: fileTypes, suggestedName: elFile.value });
    const ws = await fh.createWritable();
    await ws.write(elText.value);
    await ws.close();
    elFile.value = fh.name;
  }
  catch (e) { }
}