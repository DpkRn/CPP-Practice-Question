﻿const elOpen = document.getElementById("id_open");
const elFile = document.getElementById("id_file");
const elNumber = document.getElementById("id_number");
const elTable = document.getElementById("id_table");

const fileTypes = [
  {
    description: "Text file",
    accept: {
      "text/plain": [".xml"]
    }
  },
]

elOpen.onclick = async () => {
  try {
    const fhArray = await window.showOpenFilePicker({ types: fileTypes });
    const fh = fhArray[0];
    elFile.innerText = "file=" + fh.name;
    const fd = await fh.getFile();
    const text = await fd.text();

    let parser = new DOMParser();
    let doc = parser.parseFromString(text, "application/xml");

    let title = doc.getElementsByTagName("title");
    let authors = doc.getElementsByTagName("authors");
    let purchase_date = doc.getElementsByTagName("purchase_date");

    elNumber.innerText = "number=" + title.length;

    for (let i = 0; i < title.length; i++) {
      const tr = elTable.tBodies[0].insertRow(-1);
      const td1 = document.createElement("td");
      const td2 = document.createElement("td");
      const td3 = document.createElement("td");
      td1.innerText = title[i].textContent;
      td2.innerText = authors[i].textContent;
      td3.innerText = purchase_date[i].textContent;
      tr.innerHTML = td1.outerHTML + td2.outerHTML + td3.outerHTML;
    }
  }
  catch (e) { }
}