﻿window.onload = function () {
  chrome.tabs.create({ url: "printXml.html" }, tab => { });
}