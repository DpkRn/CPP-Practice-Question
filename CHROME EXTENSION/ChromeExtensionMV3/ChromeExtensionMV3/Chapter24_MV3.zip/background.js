﻿chrome.commands.onCommand.addListener((c) => {
  switch(c){
  case "command1":
    chrome.tabs.create({url: "https://www.wikipedia.org/"}, ()=>{});
    break;
  case "command2":
    chrome.tabs.create({url: "https://www.google.com/"}, ()=>{});
    break;
  }
});