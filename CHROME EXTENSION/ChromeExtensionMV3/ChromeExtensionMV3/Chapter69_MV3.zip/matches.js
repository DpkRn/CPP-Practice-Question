console.log("matches.js");

const button = document.createElement("button");
button.innerText = "Print";
button.onclick = () => {
  console.log("Open the print dialog.")
  chrome.runtime.sendMessage({ send_keys: "^p" });
}

document.body.insertBefore(button, document.getElementsByTagName("div")[0]);

document.getElementsByTagName("input")

for (let e of document.getElementsByTagName("input")) {
  e.onfocus = () => {
    console.dir(e);
    if (e.className == "kanji") {
      console.log("Enable IME.")
      chrome.runtime.sendMessage({ send_keys: "^{F11}" });
    }
    else {
      console.log("Disable IME.")
      chrome.runtime.sendMessage({ send_keys: "^{F12}" });
    }
  }
}