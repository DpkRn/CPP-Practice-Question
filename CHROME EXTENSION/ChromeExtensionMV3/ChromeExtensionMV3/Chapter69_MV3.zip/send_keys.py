import sys
import json
import struct
import pywinauto

def getMessage():
    rawLength = sys.stdin.buffer.read(4)
    messageLength = struct.unpack("@I", rawLength)[0]
    message = sys.stdin.buffer.read(messageLength).decode("utf-8")
    return json.loads(message)

while True:
    keys = getMessage()
    pywinauto.keyboard.send_keys(keys)
