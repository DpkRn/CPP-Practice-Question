const port = chrome.runtime.connectNative("send_keys");

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log("send_keys=" + message.send_keys);
  port.postMessage(message.send_keys);
});