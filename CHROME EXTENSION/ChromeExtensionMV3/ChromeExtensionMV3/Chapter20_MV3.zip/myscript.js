﻿window.onload = () => {
  chrome.runtime.getPlatformInfo((info) => {
    let text = "arch = " + info.arch + "\n" +
               "nacl_arch = " + info.nacl_arch + "\n" +
               "os = " + info.os;
    document.getElementById("id_text").value = text;
  });
}
